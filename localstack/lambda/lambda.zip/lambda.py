def handler(event, context):
    print('test')
    return {'foo': 'bar'}